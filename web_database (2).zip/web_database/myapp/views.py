from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

# Import modules
import smtplib, ssl
## email.mime subclasses
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
### Add new subclass for adding attachments
from email.mime.application import MIMEApplication
## The pandas library is only for generating the current date, which is not necessary for sending emails
import pandas as pd

# Define the HTML document
# Add an image element
##############################################################
def send_otp(request):
#    html = '''
#        <html>
#            <body>
#            <h2> Thanks For Registration</h2>
#                <img src='cid:Cngratulations.png' width="1000">
#            </body>
#        </html>
#    '''

    html ='''<!DOCTYPE html><html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office"><head><title>email send</title><!--[if !mso]><!--><meta http-equiv="X-UA-Compatible" content="IE=edge"/><!--<![endif]--><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><style type="text/css">#outlook a { padding:0; }
    body { margin:0;padding:0;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%; }
    table, td { border-collapse:collapse;mso-table-lspace:0pt;mso-table-rspace:0pt; }
    img { border:0;height:auto;line-height:100%; outline:none;text-decoration:none;-ms-interpolation-mode:bicubic; }
    p { display:block;margin:13px 0; }</style><!--[if mso]>
  <noscript>
  <xml>
  <o:OfficeDocumentSettings>
    <o:AllowPNG/>
    <o:PixelsPerInch>96</o:PixelsPerInch>
  </o:OfficeDocumentSettings>
  </xml>
  </noscript>
  <![endif]--><!--[if lte mso 11]>
  <style type="text/css">
    .mj-outlook-group-fix { width:100% !important; }
  </style>
  <![endif]--><!--[if !mso]><!-->
    <link href="https://fonts.googleapis.com/css?family=Ubuntu:300,400,500,700" rel="stylesheet" type="text/css"/><link href="https://fonts.googleapis.com/css?family=sans" rel="stylesheet" type="text/css"/><link href="https://fonts.googleapis.com/css?family=arial" rel="stylesheet" type="text/css"/><style type="text/css">@import url(https://fonts.googleapis.com/css?family=Ubuntu:300,400,500,700);
@import url(https://fonts.googleapis.com/css?family=sans);
@import url(https://fonts.googleapis.com/css?family=arial);</style><!--<![endif]--><style type="text/css">@media only screen and (min-width:480px) {
      .mj-column-per-67 { width:67% !important; max-width: 67%; }
.mj-column-per-33 { width:33% !important; max-width: 33%; }
.mj-column-per-100 { width:100% !important; max-width: 100%; }
.mj-column-per-50 { width:50% !important; max-width: 50%; }
    }</style><style media="screen and (min-width:480px)">.moz-text-html .mj-column-per-67 { width:67% !important; max-width: 67%; }
.moz-text-html .mj-column-per-33 { width:33% !important; max-width: 33%; }
.moz-text-html .mj-column-per-100 { width:100% !important; max-width: 100%; }
.moz-text-html .mj-column-per-50 { width:50% !important; max-width: 50%; }</style><style type="text/css">[owa] .mj-column-per-67 { width:67% !important; max-width: 67%; }
[owa] .mj-column-per-33 { width:33% !important; max-width: 33%; }
[owa] .mj-column-per-100 { width:100% !important; max-width: 100%; }
[owa] .mj-column-per-50 { width:50% !important; max-width: 50%; }</style><style type="text/css">@media only screen and (max-width:479px) {
    table.mj-full-width-mobile { width: 100% !important; }
    td.mj-full-width-mobile { width: auto !important; }
  }</style>
  <style type="text/css">

  </style>
</head>
<body style="word-spacing:normal;background-color:#dde5ff;">
    <div style="background-color:#dde5ff;">
    <!--[if mso | IE]><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
    <div style="margin:0px auto;max-width:600px;">
        <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="width:100%;">
            <tbody><tr><td style="direction:ltr;font-size:0px;padding:20px 0px 20px 0px;text-align:center;">
<!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:402px;" ><![endif]-->
                <div class="mj-column-per-67 mj-outlook-group-fix" style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                    <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="vertical-align:top;" width="100%">
                        <tbody><tr><td align="left" style="font-size:0px;padding:0px 0px 0px 25px;padding-top:0px;padding-bottom:0px;word-break:break-word;">
                    <div style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1;text-align:left;color:#000000;">
                        <p class="text-build-content" data-testid="Ou1bwQdkM-M-6zx5T7Rgs" style="margin: 10px 0; margin-top: 10px; margin-bottom: 10px;">
                            <span style="color:#8b94a7;font-family:Arial;font-size:16px;line-height:22px;">
                            </span>
                        </p>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>
<!--[if mso | IE]></td><td class="" style="vertical-align:top;width:198px;" ><![endif]-->
    <div class="mj-column-per-33 mj-outlook-group-fix" style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
        <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="vertical-align:top;" width="100%">
            <tbody><tr><td align="left" style="font-size:0px;padding:0px 25px 0px 0px;padding-top:0px;padding-bottom:0px;word-break:break-word;">
                <div style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1;text-align:left;color:#000000;">
                </div>
            </td>
        </tr>
    </tbody>
</table>
</div>
<!--[if mso | IE]></td></tr></table><![endif]-->
</td>
</tr>
</tbody>
</table>
</div>
<!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#ffffff" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><v:rect style="width:600px;" xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false"><v:fill origin="0.5, 0" position="0.5, 0" src="http://191n.mj.am/tplimg/191n/b/040q/9n65.jpeg" color="#ffffff" type="tile" /><v:textbox style="mso-fit-shape-to-text:true" inset="0,0,0,0"><![endif]-->
<div style="background:#ffffff url(&#39;http://191n.mj.am/tplimg/191n/b/040q/9n65.jpeg&#39;) center top / auto no-repeat;background-position:center top;background-repeat:no-repeat;background-size:auto;margin:0px auto;max-width:600px;">
    <div style="line-height:0;font-size:0;">
        <table align="center" background="http://191n.mj.am/tplimg/191n/b/040q/9n65.jpeg" border="0" cellpadding="0" cellspacing="0" role="presentation" style="background:#ffffff url(&#39;http://191n.mj.am/tplimg/191n/b/040q/9n65.jpeg&#39;) center top / auto no-repeat;background-position:center top;background-repeat:no-repeat;background-size:auto;width:100%;">
            <tbody><tr><td style="direction:ltr;font-size:0px;padding:70px 0px 20px 0px;padding-bottom:20px;padding-left:0px;padding-right:0px;padding-top:70px;text-align:center;">
<!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:600px;" ><![endif]-->
    <div class="mj-column-per-100 mj-outlook-group-fix" style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
        <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="vertical-align:top;" width="100%">
            <tbody>
                <tr>
                    <td align="left" style="font-size:0px;padding:10px 25px;padding-top:45px;padding-bottom:20px;word-break:break-word;"><div style="font-family:Arial, sans-serif;font-size:13px;letter-spacing:normal;line-height:1;text-align:left;color:#000000;">
                        <p class="text-build-content" style="text-align: center; margin: 10px 0; margin-top: 10px; margin-bottom: 10px;" data-testid="P8d14S07szfQSkCHR08f0">
                            <span style="color:#ffffff;font-family:Trebuchet MS;font-size:56px;line-height:56px;"><b>Thanks for sign up</b>
                            </span>
                        </p>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>
<!--[if mso | IE]></td></tr></table><![endif]-->
</td>
</tr>
</tbody>
</table>
</div>
</div>
<!--[if mso | IE]></v:textbox></v:rect></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#ffffff" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
    <div style="background:#ffffff;background-color:#ffffff;margin:0px auto;max-width:600px;">
        <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="background:#ffffff;background-color:#ffffff;width:100%;"><tbody><tr>
            <td style="direction:ltr;font-size:0px;padding:20px 0;padding-bottom:0px;padding-top:15px;text-align:center;">
<!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:600px;" ><![endif]-->
    <div class="mj-column-per-100 mj-outlook-group-fix" style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
        <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="vertical-align:top;" width="100%"><tbody><tr>
            <td align="left" style="background:#ffffff;font-size:0px;padding:10px 25px;padding-top:0px;padding-bottom:0px;word-break:break-word;">
                <div style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1;text-align:left;color:#000000;">
                <p class="text-build-content" data-testid="Wm9-icP9YGBeUGUTP_DNC" style="margin: 10px 0; margin-top: 10px; margin-bottom: 10px;">
                    <span style="color:#5e6977;font-family:Arial;font-size:15px;line-height:22px;"><b>                          Products</b>
                    </span>
                </p>
            </div>
        </td>
    </tr>
</tbody>
</table>
</div>
<!--[if mso | IE]></td></tr></table><![endif]-->
</td>
</tr>
</tbody>
</table>
</div>
<!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#ffffff" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
    <div style="background:#ffffff;background-color:#ffffff;margin:0px auto;max-width:600px;">
        <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="background:#ffffff;background-color:#ffffff;width:100%;"><tbody><tr>
            <td style="direction:ltr;font-size:0px;padding:20px 0;padding-bottom:25px;padding-top:10px;text-align:center;">
<!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:300px;" ><![endif]-->
    <div class="mj-column-per-50 mj-outlook-group-fix" style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
        <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="vertical-align:top;" width="100%"><tbody><tr>
            <td align="center" vertical-align="top" style="font-size:0px;padding:0 0 0 0;padding-top:13px;padding-right:25px;padding-bottom:0px;padding-left:25px;word-break:break-word;">
                <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="border-collapse:collapse;border-spacing:0px;"><tbody><tr>
                    <td style="width:128px;"><a href="https://www.google.com/imgres?imgurl=https%3A%2F%2F1000logos.net%2Fwp-content%2Fuploads%2F2020%2F09%2FJava-Logo.png&amp;tbnid=qt1xQyXSEQHuTM&amp;vet=12ahUKEwj3yvW66dT_AhUrL7cAHdjkAXEQMygCegUIARDoAQ..i&amp;imgrefurl=https%3A%2F%2F1000logos.net%2Fjava-logo%2F&amp;docid=20P0dWoJnqralM&amp;w=4000&amp;h=2500&amp;q=java%20image&amp;ved=2ahUKEwj3yvW66dT_AhUrL7cAHdjkAXEQMygCegUIARDoAQ" target="_blank">
                        <img alt="" src="https://0894r.mjt.lu/tplimg/0894r/b/mxzop/67wzh.png" style="border:none;border-radius:px;display:block;outline:none;text-decoration:none;height:auto;width:100%;font-size:13px;" width="128" height="auto"/></a>
                    </td>
                </tr>
            </tbody>
        </table>
    </td>
</tr>
</tbody>
</table>
</div>
<!--[if mso | IE]></td><td class="" style="vertical-align:top;width:300px;" ><![endif]-->
    <div class="mj-column-per-50 mj-outlook-group-fix" style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
        <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="vertical-align:top;" width="100%"><tbody><tr>
            <td align="left" vertical-align="top" style="font-size:0px;padding:0 0 0 0;padding-top:0px;padding-right:25px;padding-bottom:0px;padding-left:25px;word-break:break-word;">
                <div style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1;text-align:left;color:#000000;">
                    <p style="text-align: left; margin: 10px 0; margin-top: 10px;">
                        <span style="font-size:20px;text-align:left;color:#6c7582;font-family:Trebuchet MS;line-height:20px;">
                            <b>Core Java</b>
                        </span>
                    </p>
                    <p style="text-align: left; margin: 10px 0; margin-bottom: 10px;">
                        <span style="font-size:15px;text-align:left;color:#5e6977;font-family:Arial;line-height:20px;">​Java is a versatile and widely-used language known for its platform independence, robustness, and extensive libraries.</span>
                    </p>
                </div>
            </td>
        </tr>
        <tr>
            <td align="center" vertical-align="top" style="font-size:0px;padding:15px 30px;padding-top:0px;padding-right:25px;padding-bottom:10px;padding-left:25px;word-break:break-word;">
                <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="border-collapse:separate;line-height:100%;">
                    <tbody>
                        <tr>
                            <td align="center" bgcolor="#516bca" role="presentation" style="border:none;border-radius:30px;cursor:auto;mso-padding-alt:15px 30px;background:#516bca;" valign="top">
                                <a href="https://www.tutorialspoint.com/java/java_tutorial.pdf" style="display:inline-block;background:#516bca;color:#ffffff;font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;font-weight:normal;line-height:120%;margin:0;text-decoration:none;text-transform:none;padding:15px 30px;mso-padding-alt:0px;border-radius:30px;" target="_blank">
                                    <span style="font-size:15px;text-align:center;background-color:#516bca;color:#ffffff;font-family:arial;"><b>   Read More   </b>
                                    </span>
                                </a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
</div>
<!--[if mso | IE]></td></tr></table><![endif]-->
</td>
</tr>
</tbody>
</table>
</div>
<!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#ffffff" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
    <div style="background:#ffffff;background-color:#ffffff;margin:0px auto;max-width:600px;">
        <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="background:#ffffff;background-color:#ffffff;width:100%;">
            <tbody>
                <tr>
                    <td style="direction:ltr;font-size:0px;padding:20px 0;padding-bottom:2px;padding-top:2px;text-align:center;">
                        <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:300px;" ><![endif]-->
                            <div class="mj-column-per-50 mj-outlook-group-fix" style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="vertical-align:top;" width="100%">
                                    <tbody>
                                        <tr>
                                            <td align="center" vertical-align="top" style="background:#ffffff;font-size:0px;padding:0 0 0 0;padding-top:30px;padding-right:25px;padding-bottom:30px;padding-left:25px;word-break:break-word;">
                                                <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="border-collapse:collapse;border-spacing:0px;">
                                                    <tbody>
                                                        <tr>
                                                            <td style="width:128px;"><img alt="" src="https://0894r.mjt.lu/tplimg/0894r/b/mxzop/67wzq.png" style="border:none;border-radius:px;display:block;outline:none;text-decoration:none;height:auto;width:100%;font-size:13px;" width="128" height="auto"/>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        <!--[if mso | IE]></td><td class="" style="vertical-align:top;width:300px;" ><![endif]-->
                            <div class="mj-column-per-50 mj-outlook-group-fix" style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="vertical-align:top;" width="100%">
                                    <tbody>
                                        <tr>
                                            <td align="left" vertical-align="top" style="background:#ffffff;font-size:0px;padding:0 0 0 0;padding-top:20px;padding-right:25px;padding-bottom:0px;padding-left:25px;word-break:break-word;">
                                                <div style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1;text-align:left;color:#000000;">
                                                    <p style="text-align: left; margin: 10px 0; margin-top: 10px;">
                                                        <span style="font-size:20px;text-align:left;color:#6c7582;font-family:Trebuchet MS;line-height:20px;">
                                                            <b>python for beginners</b>
                                                        </span>
                                                    </p>
                                                    <p style="text-align: left; margin: 10px 0; margin-bottom: 10px;">
                                                        <span style="font-size:15px;text-align:left;color:#5e6977;font-family:Arial;line-height:20px;">Python is a versatile and powerful language known for its simplicity and readability.</span>
                                                    </p>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="center" vertical-align="top" style="background:#ffffff;font-size:0px;padding:15px 30px;padding-top:22px;padding-right:25px;padding-bottom:26px;padding-left:25px;word-break:break-word;">
                                                <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="border-collapse:separate;line-height:100%;">
                                                    <tbody>
                                                        <tr>
                                                            <td align="center" bgcolor="#516bca" role="presentation" style="border:none;border-radius:30px;cursor:auto;mso-padding-alt:15px 30px;background:#516bca;" valign="top">
                                                                <a href="https://bugs.python.org/file47781/Tutorial_EDIT.pdf" style="display:inline-block;background:#516bca;color:#ffffff;font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;font-weight:normal;line-height:120%;margin:0;text-decoration:none;text-transform:none;padding:15px 30px;mso-padding-alt:0px;border-radius:30px;" target="_blank">
                                                                    <span style="font-size:15px;text-align:center;background-color:#516bca;color:#ffffff;font-family:arial;">
                                                                        <b>   Read More    </b>
                                                                    </span>
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!--[if mso | IE]></td></tr></table><![endif]-->
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#ffffff" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
            <div style="background:#ffffff;background-color:#ffffff;margin:0px auto;max-width:600px;">
                <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="background:#ffffff;background-color:#ffffff;width:100%;">
                    <tbody>
                        <tr>
                            <td style="direction:ltr;font-size:0px;padding:20px 0;padding-top:15px;text-align:center;">
                                <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:300px;" ><![endif]-->
                                    <div class="mj-column-per-50 mj-outlook-group-fix" style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                        <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="vertical-align:top;" width="100%">
                                            <tbody>
                                                <tr>
                                                    <td align="center" vertical-align="top" style="font-size:0px;padding:15px 25px 0px 25px;padding-top:15px;padding-right:25px;padding-bottom:0px;padding-left:25px;word-break:break-word;">
                                                        <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="border-collapse:collapse;border-spacing:0px;">
                                                            <tbody>
                                                                <tr>
                                                                    <td style="width:128px;"><img alt="" src="https://0894r.mjt.lu/tplimg/0894r/b/mxzop/67wtl.png" style="border:none;border-radius:0;display:block;outline:none;text-decoration:none;height:auto;width:100%;font-size:13px;" width="128" height="auto"/>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!--[if mso | IE]></td><td class="" style="vertical-align:top;width:300px;" ><![endif]-->
                                        <div class="mj-column-per-50 mj-outlook-group-fix" style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="vertical-align:top;" width="100%">
                                                <tbody>
                                                    <tr>
                                                        <td align="left" vertical-align="top" style="font-size:0px;padding:0 0 0 0;padding-top:5px;padding-right:25px;padding-bottom:0px;padding-left:25px;word-break:break-word;">
                                                            <div style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1;text-align:left;color:#000000;">
                                                                <p style="text-align: left; margin: 10px 0; margin-top: 10px;">
                                                                    <span style="font-size:20px;text-align:left;color:#6c7582;font-family:Trebuchet MS;line-height:20px;">
                                                                        <b>AI/ML Courses</b>
                                                                    </span>
                                                                </p>
                                                                <p style="text-align: left; margin: 10px 0; margin-bottom: 10px;">
                                                                    <span style="font-size:15px;text-align:left;color:#5e6977;font-family:Arial;line-height:20px;">Artificial Intelligence and Machine Learning is a branch of study or discipline.</span>
                                                                </p>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center" vertical-align="top" style="font-size:0px;padding:22px 25px 10px 25px;padding-top:22px;padding-right:25px;padding-bottom:10px;padding-left:25px;word-break:break-word;">
                                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="border-collapse:separate;line-height:100%;">
                                                                <tbody>
                                                                    <tr>
                                                                        <td align="center" bgcolor="#516bca" role="presentation" style="border:none;border-radius:30px;cursor:auto;mso-padding-alt:15px 25px 15px 25px;background:#516bca;" valign="top">
                                                                            <a href="https://mrcet.com/downloads/digital_notes/ECE/III%20Year/AI%20&%20ML%20DIGITAL%20NOTES.pdf" style="display:inline-block;background:#516bca;color:#ffffff;font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;font-weight:normal;line-height:120%;margin:0;text-decoration:none;text-transform:none;padding:15px 25px 15px 25px;mso-padding-alt:0px;border-radius:30px;" target="_blank">
                                                                                <span style="font-size:15px;text-align:center;background-color:#516bca;color:#ffffff;font-family:arial;">
                                                                                    <b>   Read More   </b>
                                                                                </span>
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <!--[if mso | IE]></td></tr></table><![endif]-->
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
<!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#ffffff" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
    <div style="background:#ffffff;background-color:#ffffff;margin:0px auto;max-width:600px;">
        <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="background:#ffffff;background-color:#ffffff;width:100%;">
            <tbody>
                <tr>
                    <td style="direction:ltr;font-size:0px;padding:20px 0;padding-top:15px;text-align:center;">
                        <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:300px;" ><![endif]-->
                            <div class="mj-column-per-50 mj-outlook-group-fix" style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="vertical-align:top;" width="100%">
                                    <tbody>
                                        <tr>
                                            <td align="center" vertical-align="top" style="font-size:0px;padding:15px 25px 0px 25px;padding-top:15px;padding-right:25px;padding-bottom:0px;padding-left:25px;word-break:break-word;">
                                                <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="border-collapse:collapse;border-spacing:0px;">
                                                    <tbody>
                                                        <tr>
                                                            <td style="width:250px;"><img alt="" src="https://0894r.mjt.lu/tplimg/0894r/b/mxzop/67w6p.jpeg" style="border:none;border-radius:0;display:block;outline:none;text-decoration:none;height:auto;width:100%;font-size:13px;" width="250" height="auto"/>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
<!--[if mso | IE]></td><td class="" style="vertical-align:top;width:300px;" ><![endif]-->
    <div class="mj-column-per-50 mj-outlook-group-fix" style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
        <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="vertical-align:top;" width="100%">
            <tbody>
                <tr>
                    <td align="left" vertical-align="top" style="font-size:0px;padding:0 0 0 0;padding-top:5px;padding-right:25px;padding-bottom:0px;padding-left:25px;word-break:break-word;">
                        <div style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1;text-align:left;color:#000000;">
                            <p style="text-align: left; margin: 10px 0; margin-top: 10px;">
                                <span style="font-size:20px;text-align:left;color:#6c7582;font-family:Trebuchet MS;line-height:20px;">
                                    <b>Data Science Course</b>
                                </span>
                            </p>
                            <p style="text-align: left; margin: 10px 0; margin-bottom: 10px;">
                                <span style="font-size:15px;text-align:left;color:#5e6977;font-family:Arial;line-height:20px;">Data science is the domain of study that deals with vast volumes of data using modern tools and techniques.
                                </span>
                            </p>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td align="center" vertical-align="top" style="font-size:0px;padding:22px 25px 10px 25px;padding-top:22px;padding-right:25px;padding-bottom:10px;padding-left:25px;word-break:break-word;">
                        <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="border-collapse:separate;line-height:100%;">
                            <tbody>
                                <tr>
                                    <td align="center" bgcolor="#516bca" role="presentation" style="border:none;border-radius:30px;cursor:auto;mso-padding-alt:15px 25px 15px 25px;background:#516bca;" valign="top">
                                        <a href="https://aws.amazon.com/what-is/data-science/#:~:text=Data%20science%20is%20the%20study,analyze%20large%20amounts%20of%20data." style="display:inline-block;background:#516bca;color:#ffffff;font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;font-weight:normal;line-height:120%;margin:0;text-decoration:none;text-transform:none;padding:15px 25px 15px 25px;mso-padding-alt:0px;border-radius:30px;" target="_blank">
                                            <span style="font-size:15px;text-align:center;background-color:#516bca;color:#ffffff;font-family:arial;">
                                                <b>   Read More   </b>
                                            </span>
                                        </a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <!--[if mso | IE]></td></tr></table><![endif]-->
</td>
</tr>
</tbody>
</table>
</div>

                        <!--[if mso | IE]></td><td class="" style="vertical-align:top;width:300px;" ><![endif]-->
                            
<!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#ffffff" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><v:rect style="width:600px;" xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false"><v:fill origin="0.5, 0" position="0.5, 0" src="http://191n.mj.am/tplimg/191n/b/040q/9n6h.jpeg" color="#ffffff" type="tile" /><v:textbox style="mso-fit-shape-to-text:true" inset="0,0,0,0"><![endif]-->
    <div style="background:#ffffff url(&#39;http://191n.mj.am/tplimg/191n/b/040q/9n6h.jpeg&#39;) center top / auto no-repeat;background-position:center top;background-repeat:no-repeat;background-size:auto;margin:0px auto;max-width:600px;">
        <div style="line-height:0;font-size:0;">
            <table align="center" background="http://191n.mj.am/tplimg/191n/b/040q/9n6h.jpeg" border="0" cellpadding="0" cellspacing="0" role="presentation" style="background:#ffffff url(&#39;http://191n.mj.am/tplimg/191n/b/040q/9n6h.jpeg&#39;) center top / auto no-repeat;background-position:center top;background-repeat:no-repeat;background-size:auto;width:100%;">
                <tbody>
                    <tr>
                        <td style="direction:ltr;font-size:0px;padding:20px 0;padding-bottom:31px;text-align:center;">
                            <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:600px;" ><![endif]-->
                                <div class="mj-column-per-100 mj-outlook-group-fix" style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                    <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="vertical-align:top;" width="100%">
                                        <tbody>
                                            <tr>
                                                <td align="left" style="font-size:0px;padding:10px 25px;padding-top:10px;padding-bottom:10px;word-break:break-word;">
                                                    <div style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1;text-align:left;color:#000000;">
                                                        <p class="text-build-content" style="text-align: center; margin: 10px 0; margin-top: 10px; margin-bottom: 10px;" data-testid="19A0dSioybNlfLcgVemKk">
                                                            <span style="color:#ffffff;font-family:Trebuchet MS;font-size:26px;line-height:22px;">
                                                                <b>Contact Us</b>
                                                            </span>
                                                        </p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <!--[if mso | IE]></td></tr></table><![endif]-->
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <!--[if mso | IE]></v:textbox></v:rect></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#ffffff" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><v:rect style="width:600px;" xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false"><v:fill origin="0.5, 0" position="0.5, 0" src="http://191n.mj.am/tplimg/191n/b/040q/9n6h.jpeg" color="#ffffff" type="tile" /><v:textbox style="mso-fit-shape-to-text:true" inset="0,0,0,0"><![endif]-->
            <div style="background:#ffffff url(&#39;http://191n.mj.am/tplimg/191n/b/040q/9n6h.jpeg&#39;) center top / auto no-repeat;background-position:center top;background-repeat:no-repeat;background-size:auto;margin:0px auto;max-width:600px;">
                <div style="line-height:0;font-size:0;">
                    <table align="center" background="http://191n.mj.am/tplimg/191n/b/040q/9n6h.jpeg" border="0" cellpadding="0" cellspacing="0" role="presentation" style="background:#ffffff url(&#39;http://191n.mj.am/tplimg/191n/b/040q/9n6h.jpeg&#39;) center top / auto no-repeat;background-position:center top;background-repeat:no-repeat;background-size:auto;width:100%;">
                        <tbody>
                            <tr>
                                <td style="direction:ltr;font-size:0px;padding:20px 0;padding-bottom:31px;text-align:center;">
                                    <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:600px;" ><![endif]-->
                                        <div class="mj-column-per-100 mj-outlook-group-fix" style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="vertical-align:top;" width="100%">
                                                <tbody>
                                                    <tr>
                                                        <td align="center" style="font-size:0px;padding:10px 25px;word-break:break-word;">
                                                            <!--[if mso | IE]><table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" ><tr><td><![endif]-->
                                                                <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="float:none;display:inline-table;">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td style="padding:4px;vertical-align:middle;">
                                                                                <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="background:#3B5998;border-radius:3px;width:20px;">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td style="font-size:0;height:20px;vertical-align:middle;width:20px;">
                                                                                                <a href="https://www.facebook.com/sharer/sharer.php?u=" target="_blank">
                                                                                                    <img height="20" src="https://www.mailjet.com/images/theme/v1/icons/ico-social/facebook.png" style="border-radius:3px;display:block;" width="20"/>
                                                                                                </a>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                                <!--[if mso | IE]></td><td><![endif]-->
                                                                    <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="float:none;display:inline-table;">
                                                                        <tbody><tr><td style="padding:4px;vertical-align:middle;">
                                                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="background:#1DA1F2;border-radius:3px;width:20px;">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td style="font-size:0;height:20px;vertical-align:middle;width:20px;">
                                                                                            <a href="https://twitter.com/intent/tweet?url=" target="_blank">
                                                                                                <img height="20" src="https://www.mailjet.com/images/theme/v1/icons/ico-social/twitter.png" style="border-radius:3px;display:block;" width="20"/>
                                                                                            </a>
                                                                                        </td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                            <!--[if mso | IE]></td><td><![endif]-->
                                                                <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="float:none;display:inline-table;">
                                                                    <tbody><tr><td style="padding:4px;vertical-align:middle;">
                                                                        <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="background:#405DE6;border-radius:3px;width:20px;">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td style="font-size:0;height:20px;vertical-align:middle;width:20px;">
                                                                                        <a href="" target="_blank">
                                                                                            <img height="20" src="https://www.mailjet.com/images/theme/v1/icons/ico-social/instagram.png" style="border-radius:3px;display:block;" width="20"/>
                                                                                        </a>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <!--[if mso | IE]></td><td><![endif]-->
                                                            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="float:none;display:inline-table;">
                                                                <tbody>
                                                                    <tr>
                                                                        <td style="padding:4px;vertical-align:middle;">
                                                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="background:#0077B5;border-radius:3px;width:20px;">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td style="font-size:0;height:20px;vertical-align:middle;width:20px;"><img height="20" src="https://www.mailjet.com/images/theme/v1/icons/ico-social/linkedin.png" style="border-radius:3px;display:block;" width="20"/>
                                                                                        </td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                            <!--[if mso | IE]></td></tr></table><![endif]-->
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <!--[if mso | IE]></td></tr></table><![endif]-->
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                
</body>
</html>
'''
##############################################################

# Define a function to attach files as MIMEApplication to the email
    ## Add another input extra_headers default to None
##############################################################
    if request.method == 'POST':
            email = request.POST.get('email')
    def attach_file_to_email(email_message, filename):
    # Open the attachment file for reading in binary mode, and make it a MIMEApplication class
        filename = r'C:\Users\Shravani\emailotp\static\Cngratulations.png'
        with open(filename, "rb") as f:
            file_attachment = MIMEApplication(f.read())
    # Add header/name to the attachments    
        file_attachment.add_header(
            "Content-Disposition",
            f"attachment; filename= {filename}",
        )
        #email_message.attach(file_attachment)
# Set up the input extra_headers for img
## Default is None: since for regular file attachments, it's not needed
## When given a value: the following code will run
### Used to set the cid for image
#       if extra_headers is not None:
#            for name, value in extra_headers.items():
#                file_attachment.add_header(name, value)
# Attach the file to the message
        email_message.attach(file_attachment)
##############################################################    

# Set up the email addresses and password. Please replace below with your email address and password
    email_from = 'shruu654@gmail.com'
    password = 'wdosdaqbpucjyrwo'
    email_to = email


    subject = "Welcome to the team "

# Create a MIMEMultipart class, and set up the From, To, Subject fields
    email_message = MIMEMultipart()
    email_message['From'] = email_from
    email_message['To'] = email_to
    email_message['Subject'] = subject

# Attach the html doc defined earlier, as a MIMEText html content type to the MIME message
    email_message.attach(MIMEText(html, "html"))

# Attach more (documents)
## Apply function with extra_header on chart.png. This will render chart.png in the html content
##############################################################
#    attach_file_to_email(email_message, 'Cngratulations.png', {'Content-ID': r'<C:\Users\Shravani\emailotp\static\Cngratulations.png>'})
##############################################################


# Convert it as a string
    email_string = email_message.as_string()

# Connect to the Gmail SMTP server and Send Email
    context = ssl.create_default_context()
    with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
        server.login(email_from, password)
        server.sendmail(email_from, email_to, email_string)
        return HttpResponse(server) 

def home(request):

    return render(request, "home.html")
