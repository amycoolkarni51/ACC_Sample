''' Added By:- Shruti Bathe  (Vishal sir part is down)       
    Task:- For signup , login , contact, (register(by Vishal Sir details are down) )
    Function name:-
            def index   :-   signup
            def contact :-   contact
            def login   :-   login   '''


from django.shortcuts import redirect, render
import mysql.connector
from django.contrib import messages

# Create your views here.
# index page where we have signup also 
def index(request):
    if request.method=="POST":
        # connection with database
        conn = mysql.connector.connect(user='root', password='root', host='localhost',port=3306,database='web',auth_plugin='mysql_native_password')
        cursor=conn.cursor()
        d=request.POST
        # table field's data 
        for key,value in d.items():
            if key=="Full_Name":
                Full_Name=value
            if key=="EmailId":
                EmailId=value
            if key=='Password':
                Password=value
            if key=='Confirm_Password':
                Confirm_Password=value

        # checking conditions
        if len(Full_Name)<2 or len(EmailId)<2 or len(Password)<2 or len(Confirm_Password)<2:
            messages.error(request,"Please Enter All the Details Carefully!! Fields Should Not Be Empty")
        else:
            # inserting data into signup table          
            c="insert into signup(Full_Name,EmailId,Password,Confirm_Password) values('%s','%s','%s','%s')"%(Full_Name,EmailId,Password,Confirm_Password)
            cursor.execute(c)
            conn.commit()
            messages.success(request,'Your Successfully SignUp!!')
            return render(request,'login.html')
    return render(request,'index.html')
    
# contact page 
def contact(request):
    if request.method=="POST":
        # connection with database
        conn = mysql.connector.connect(user='root', password='root', host='localhost',port=3306,database='web',auth_plugin='mysql_native_password')
        cursor=conn.cursor()
        d=request.POST
        # table field's data 
        for key,value in d.items():
            if key=="First_Name":
                First_Name=value
            if key=="Last_Name":
                Last_Name=value
            if key=="EmailId":
                EmailId=value
            if key=="Location":
                Location=value
            if key=="Message":
                Message=value
        
        # checking condition
        if len(First_Name)<2 or len(Last_Name)<2 or len(EmailId)<2 or len(Location)<2 or len(Message)==0:
            messages.error(request,"Please Enter All the Details Carefully!! Fields Should Not Be Empty")
        else:
            # inserting data into contact table          
            c="insert into contact(First_Name,Last_Name,EmailId,Location,Message) values('%s','%s','%s','%s','%s')"%(First_Name,Last_Name,EmailId,Location,Message)
            cursor.execute(c)
            conn.commit()
            messages.success(request,'Your Message has been send Successfully!!')
            contact=tuple(cursor.fetchall()) 
            return render(request,'admin_dashboard.html',{'contact':contact})
    return render(request,'contact_us.html')

# login page
def login(request):
    global UserName,EmailId,Password
    if request.method=="POST":
        # connection with database
        conn = mysql.connector.connect(user='root', password='root', host='localhost',port=3306,database='web',auth_plugin='mysql_native_password')
        cursor=conn.cursor()
        data=request.POST
        # table field's data 
        for key,value in data.items():
            if key=='UserName':
                UserName=value
            if key=='EmailId':
                EmailId=value
            if key=='Password':
                Password=value
              
                          
         # selecting only email and password from signup tale                     
        query="select * from signup where EmailId='{}' and Password='{}'".format(EmailId,Password)  
        cursor.execute(query)
        t=tuple(cursor.fetchall())
            
        if t==():
            messages.error(request,"Kindly SignUp First!!")
            #messages.error(request,"If you have already register then might be your login details and your registration details are not matching")
            return render(request,'index.html') 
        else:
            query2="select * from registeration where EmailId='{}' and Password='{}'".format(EmailId,Password)
            cursor.execute(query2)
            result=tuple(cursor.fetchall())
            return render(request,'course.html',{'result':result}) 
            #return render(request,'frontend.html') 
    return render(request,'login.html')



"""Added By:-           Vishal patil (Database Team)
   Function Name:-      register
   Date:-               13/06/2023"""

def registeration(request):
    global Full_Name,EmailId,Mobile,Gender,Profession,Qualification,Courses,City,Password
    if request.method=="POST":
        conn = mysql.connector.connect(user='root', password='root', host='localhost',port=3306,database='web',auth_plugin='mysql_native_password')
        cursor=conn.cursor()
        d=request.POST
        
        for key,value in d.items():
            if key=="Full_Name":
                Full_Name=value
            if key=="EmailId":
                EmailId=value
            if key=="Mobile":
                Mobile=value
            if key=="Gender":
                Gender=value
            if key=="City":
                City=value
            if key=="Qualification":
                Qualification=value
            if key=="Profession":
                Profession=value
            if key=="Courses":
                Courses=value
            if key=="Password":
                Password=value
            
        
        c="insert into registeration(Full_Name,EmailId,Mobile,Gender,City,Qualification,Profession,Courses,Password) values('%s','%s','%s','%s','%s','%s','%s','%s','%s')"%(Full_Name,EmailId,Mobile,Gender,City,Qualification,Profession,Courses,Password)
        cursor.execute(c)
        conn.commit()
        messages.success(request,"Congratulation! You have Successfully Registered!!! Kindly go to the home page for login!!")
    return render(request,'registeration.html')
    
    
def coursepage(request):
   return render(request, 'course.html')


def frontend(request):
   return render(request,'frontend.html')