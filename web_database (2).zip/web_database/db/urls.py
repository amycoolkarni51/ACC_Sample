from django.urls import path,include

from db import views



urlpatterns = [
    path('', views.index ,name="index"),
    path('contact/', views.contact ,name="contact"),
    #path('check/', views.check ,name="check"),
    path('login/', views.login ,name="login"), 
    path('registeration/', views.registeration ,name="registeration"),

    path('course.html', views.coursepage, name="coursepage"),

    path('frontend',views.frontend, name="frontend"),

   

]