''' Added by Shruti Bathe and Vishal Patil - Description below'''

from django.shortcuts import redirect, render
import pymysql as sql
from django.contrib import messages
from .models import Registeration
from .models import SignUp
from .models import Contact
from django.template import loader
from django.http import HttpResponse
import mysql.connector


''' Added By:- Shruti Bathe  
    Task:- For signup
    Function name:-
            def index   :-   signup '''
            
# index page where we have signup also 
def index(request):
    if request.method=="POST":
        # connection with database
        m=mysql.connector.connect(host="localhost",user="root",password="",database="web_db")
        cursor=m.cursor()
        d=request.POST
        # table field's data 
        for key,value in d.items():
            if key=="Full_Name":
                Full_Name=value
            if key=="EmailId":
                EmailId=value
            if key=='Password':
                Password=value
            if key=='Confirm_Password':
                Confirm_Password=value

        # checking conditions
        if len(Full_Name)<2 or len(EmailId)<2 or len(Password)<2 or len(Confirm_Password)<2:
            messages.error(request,"Please Enter All the Details Carefully!! Fields Should Not Be Empty")
        else:
            # inserting data into signup table          
            c="insert into signup(Full_Name,EmailId,Password,Confirm_Password) values('%s','%s','%s','%s')"%(Full_Name,EmailId,Password,Confirm_Password)
            cursor.execute(c)
            m.commit()
            #messages.success(request,'Your Successfully SignUp!!')
            return render(request,'login.html')
    else:
        return render(request,'index.html')
    

''' Added By:- Shruti Bathe  
    Task:- For contact
    Function name:-
            def contact   :-   contact '''
def contact(request):
    if request.method=="POST":
        # connection with database
        m=mysql.connector.connect(host="localhost",user="root",password="",database="web_db")
        cursor=m.cursor()
        d=request.POST
        # table field's data 
        for key,value in d.items():
            if key=="First_Name":
                First_Name=value
            if key=="Last_Name":
                Last_Name=value
            if key=="EmailId":
                EmailId=value
            if key=="Location":
                Location=value
            if key=="Message":
                Message=value
        
        # checking condition
        if len(First_Name)<2 or len(Last_Name)<2 or len(EmailId)<2 or len(Location)<2 or len(Message)==0:
            messages.error(request,"Please Enter All the Details Carefully!! Fields Should Not Be Empty")
        else:
            # inserting data into contact table          
            c="insert into contact(First_Name,Last_Name,EmailId,Location,Message) values('%s','%s','%s','%s','%s')"%(First_Name,Last_Name,EmailId,Location,Message)
            cursor.execute(c)
            m.commit()
            #messages.success(request,'Your Message has been send Successfully!!')
    return render(request,'contactus.html')


''' Added By:- Shruti Bathe  
    Task:- For login
    Function name:-
            def login   :-   login '''
def login(request):
    global UserName,EmailId,Password
    if request.method=="POST":
        # connection with database
        m=mysql.connector.connect(host="localhost",user="root",password="" ,database="web_db")
        cursor=m.cursor()
        data=request.POST
        # table field's data 
        for key,value in data.items():
            if key=='UserName':
                UserName=value
            if key=='EmailId':
                EmailId=value
            if key=='Password':
                Password=value
                          
         # selecting only email and password from signup tale                     
        query="select * from signup where EmailId='{}' and Password='{}'".format(EmailId,Password)  
        cursor.execute(query)
        t=tuple(cursor.fetchall())
            
        if t==():
            messages.error(request,"Kindly SignUp First!!")
            #messages.error(request,"If you have already register then might be your login details and your registration details are not matching")
            return render(request,'index.html') 
        else:
            return render(request,'course.html') 
    return render(request,'login.html')


''' Added By:- Shruti Bathe  
    Task:- For those who have already register login
    Function name:-
            def registerlogin   :-   For those who have already register login '''
def registerlogin(request):
    global UserName,EmailId,Password
    if request.method=="POST":
        # connection with database
        m=mysql.connector.connect(host="localhost",user="root",password="" ,database="web_db")
        cursor=m.cursor()
        data=request.POST
        # table field's data 
        for key,value in data.items():
            if key=='EmailId':
                EmailId=value
            if key=='Password':
                Password=value
                          
         # selecting only email and password from signup tale                     
        query="select * from registeration where EmailId='{}' and Password='{}'".format(EmailId,Password)  
        cursor.execute(query)
        t=tuple(cursor.fetchall())
            
        if t==():
            messages.error(request,"Kindly SignUp First!!")
            #messages.error(request,"If you have already register then might be your login details and your registration details are not matching")
            return render(request,'registeration.html')   
        else:
            query2="select * from registeration where EmailId='{}' and Password='{}'".format(EmailId,Password)
            cursor.execute(query2)
            result=tuple(cursor.fetchall())
            return render(request,'student_dashboard.html',{'result':result})
    return render(request,'registerlogin.html')

def registeration(request):
    global First_Name,Last_Name,UserName,Address,Profession,Courses,EmailId,Password
    if request.method=="POST":
        m=mysql.connector.connect(host="localhost",user="root",password="",database="web_db")
        cursor=m.cursor()
        d=request.POST
        
        for key,value in d.items():
            if key=="Full_Name":
                Full_Name=value
            if key=="EmailId":
                EmailId=value
            if key=="Mobile":
                Mobile=value
            if key=="Gender":
                Gender=value
            if key=="City":
                City=value
            if key=="Qualification":
                Qualification=value
            if key=="Profession":
                Profession=value
            if key=="Courses":
                Courses=value
            if key=="Password":
                Password=value
            
        
        c="insert into registeration(Full_Name,EmailId,Mobile,Gender,City,Qualification,Profession,Courses,Password) values('%s','%s','%s','%s','%s','%s','%s','%s','%s')"%(Full_Name,EmailId,Mobile,Gender,City,Qualification,Profession,Courses,Password)
        cursor.execute(c)
        m.commit()
        messages.success(request,"Congratulation! You have Successfully Registered!!! Kindly go to the home page for login!!")
        return render(request,'registerlogin.html')
    return render(request,'registeration.html')


''' Added By:- Shruti Bathe  
    Task:- For deleting the register student from admin dashboard
    Function name:-
            def DeleteRegistration   :-   to delete the student from admin dashboard those who registered '''
def DeleteRegistration(request,key):
    m=mysql.connector.connect(host="localhost",user="root",passwd="" ,database="web_db")
    cursor=m.cursor()
    query="delete from registeration where id='{}'".format(key)
    cursor.execute(query)
    m.commit()
    return redirect('admin_dashboard_registration')


''' Added By:- Shruti Bathe  
    Task:- For deleting the contact student from admin dashboard
    Function name:-
            def DeleteContact  :-   to delete the student from admin dashboard those who contacted  '''
def DeleteContact(request,key):
    m=mysql.connector.connect(host="localhost",user="root",passwd="" ,database="web_db")
    cursor=m.cursor()
    query="delete from contact where id='{}'".format(key)
    cursor.execute(query)
    m.commit()
    return redirect('admin_dashboard_registration')


''' Added By:- Shruti Bathe  
    Task:- For deleting the signup student from admin dashboard
    Function name:-
            def DeleteContact  :-   to delete the student from admin dashboard those who signup  '''
def DeleteSignup(request,key):
    m=mysql.connector.connect(host="localhost",user="root",passwd="" ,database="web_db")
    cursor=m.cursor()
    query="delete from signup where id='{}'".format(key)
    cursor.execute(query)
    m.commit()
    return redirect('admin_dashboard_registration')



''' Added By:- Shruti Bathe  
    Task:- For deleting the register student from admin dashboard
    Function name:-
            def DeleteRegistration   :-   to delete the student from admin dashboard those who registered '''
def RegistrationApproved(request,key):
    m=mysql.connector.connect(host="localhost",user="root",passwd="" ,database="web_db")
    cursor=m.cursor()
    query="update registeration SET Status='Approved' where id='{}'".format(key)
    cursor.execute(query)
    m.commit()
    return redirect('admin_dashboard_registration')



''' Added By:- Shruti Bathe  
    Task:- For student dashboard
    Function name:-
            def student_dashboard  :-   student dashboard  '''
def student_dashboard(request):
    return render(request,'student_dashboard.html')
    
    


"""Added By:-           Vishal patil (Database Team)
   Function Name:-      data fetching for admin Dashboard 
   Date:-               24/06/2023"""

def admin_dashboard_registration(request):
  Info = Registeration.objects.all().values()
  sign= SignUp.objects.all().values()
  contact= Contact.objects.all().values()
  template = loader.get_template('admin_dashboard.html')
  context = {
    'Info': Info,
    'sign': sign,
    'contact':contact
  }
  return HttpResponse(template.render(context, request))




"""Added By:-           Vishal patil (Database Team)
   Function Name:-      register
   Date:-               13/06/2023"""
def main(request):
   return render(request, 'main.html')

def ourcourses(request):
   return render(request, 'course.html')

def coursepage(request):
   return render(request, 'course.html')

def frontend(request):
   return render(request,'frontend.html')

def html(request):
   return render(request, 'Html.html')

def css(request):
   return render(request, "css.html")

def javascript(request):
   return render(request, "javascript.html")

def ReactJS(request):
   return render(request, "reactjs.html")

def jQuery(request):
   return render(request, "jquery.html")

def AngularJS(request):
   return render(request, "angularjs.html")


def backend(request):
   return render(request,'backend.html')

def python(request):
    return render(request,'python.html')

def java(request):
    return render(request,'java.html')

def cc(request):
    return render(request,'cc++.html')

def kotlin(request):
    return render(request,'kotlin.html')

def scale(request):
    return render(request,'scale.html')

def php(request):
    return render(request,'php.html')


def database(request):
   return render(request,'database.html')

def oracle(request):
    return render(request, 'oracle.html')

def sql_page(request):
    return render(request,'sql_page.html')

def postgresql(request):
    return render(request, 'pssql.html')

def mangodb(request):
    return render(request, 'mangodb.html')

def sqlite(request):
    return render(request, 'sqlite.html')

def sqlserver(request):
    return render(request, 'sqlserver.html')


def marketing(request):
   return render(request, 'marketing.html')

def digitalmark(request):
    return render(request, 'digital.html')

def socialmediamark(request):
    return render(request, 'social media.html')

def contentmark(request):
    return render(request, 'content mark.html')

def directmark(request):
    return render(request, 'direct mark.html')

def salesmark(request):
    return render(request, 'sales.html')

def brandmark(request):
    return render(request,'brand.html')

def faculty(request):
    return render(request,'faculty.html')

def about(request):
    return render(request,'about.html')

        