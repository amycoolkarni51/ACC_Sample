from django.urls import path,include

from db import views



urlpatterns = [
    path('', views.index ,name="index"),
    path('contact/', views.contact ,name="contact"),
    #path('check/', views.check ,name="check"),
    path('login/', views.login ,name="login"), 
    #path('signup/', views.signup ,name="signup"), 
    path('registration/', views.registeration ,name="registeration"),
    path('admin_dashboard/',views.admin_dashboard_registration,name="admin_dashboard_registration"),
    path('student_dashboard/',views.student_dashboard,name="student_dashboard"),
    path('contact_us/',views.contact,name="contact"),
    path('signup/', views.index ,name="index"),
    path('DeleteRegistration/<int:key>', views.DeleteRegistration ,name="DeleteRegistration"),
    path('DeleteContact/<int:key>', views.DeleteContact ,name="DeleteContact"),
    path('DeleteSignup/<int:key>', views.DeleteSignup ,name="DeleteSignup"),
    path('RegistrationAprroved/<int:key>' ,views.RegistrationApproved , name="RegistrationApproved"),
    path('registerlogin/', views.registerlogin , name="registerlogin"),


    path('course/', views.coursepage, name="coursepage"),
    path('course/',views.ourcourses, name="ourcourses"),

    path('frontend/',views.frontend, name="frontend"),
    path('Html/',views.html,name="Html"),
    path("css/",views.css, name="css"),
    path("javascript/",views.javascript, name="javascript"),
    path("angularjs/",views.AngularJS, name="angularjs"),
    path("reactjs/",views.ReactJS, name="reactjs"),
    path("jquery/",views.jQuery, name="jquery"),

    path('backend/',views.backend, name="backend"),
    path('python/',views.python, name="python"),
    path('java/',views.java, name="java"),
    path("cc++/",views.cc,name="cc++"),
    path("kotlin/",views.kotlin, name="kotlin"),
    path("scale/",views.scale, name="scale"),
    path('php/',views.php,name="php"),

    path('database/',views.database, name="database"),
    path('oracle/',views.oracle, name="oracle"),
    path('sql_page/',views.sql_page, name='sql_page'),
    path('pssql/',views.postgresql, name="pssql"),
    path('mangodb/',views.mangodb, name="mangodb"),
    path('sqlite/',views.sqlite, name="sqlite"),
    path('sqlserver/',views.sqlserver, name="sqlserver"),

    path('marketing/',views.marketing, name="marketing"),
    path('digital/',views.digitalmark, name="digital"),
    path('social media/',views.socialmediamark, name="social media"),
    path('content mark/',views.contentmark, name="content mark"),
    path('direct mark/',views.directmark, name="direct mark"),
    path('sales/',views.salesmark, name="sales"),
    path('brand/',views.brandmark, name="brand"),
    path('main', views.main, name="main"),
    path('faculty', views.faculty, name="faculty"),
    
    path('about', views.about, name="about"),
]